package com.example.tetrisgame;

import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

public class Form {
    Rectangle a;
    Rectangle b;
    Rectangle c;
    Rectangle d;
    Color color;
    private String name;
    public int form = 1;

    public Form(Rectangle a, Rectangle b, Rectangle c, Rectangle d) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
    }

    public Form(Rectangle a, Rectangle b, Rectangle c, Rectangle d, String name) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.name = name;

        switch(name) {
            case "l" -> {
                color = Color.GREEN;
            }
            case "j" -> {
                color = Color.BLUE;
            }
            case "o" -> {
                color = Color.CRIMSON;
            }
            case "s" -> {
                color = Color.GOLD;
            }
            case "t" -> {
                color = Color.CHOCOLATE;
            }
            case "z" -> {
                color = Color.HOTPINK;
            }
            case "i" -> {
                color = Color.ORANGE;
            }
        }
        a.setFill(color);
        b.setFill(color);
        c.setFill(color);
        d.setFill(color);
    }

    public String getName() {
        return name;
    }

    public void changeForm(){
        if(form!=4){
            form++;
        }
        else{
            form = 1;
        }
    }
}
