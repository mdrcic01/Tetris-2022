package com.example.tetrisgame;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.shape.Rectangle;

public class Controller {
    public static final int SIZE = Tetris.SIZE;
    public static final int MOVE = Tetris.MOVE;
    public static int XMAX = Tetris.XMAX;
    public static int YMAX = Tetris.YMAX;
    public static int [][] MESH = Tetris.MESH;

    public static void moveRight(Form form){
        if(form.a.getX() + MOVE <= XMAX - SIZE && form.b.getX() + MOVE <= XMAX - SIZE &&
        form.c.getX() + MOVE <= XMAX - SIZE && form.d.getX() + MOVE <= XMAX - SIZE){
            int moveA = MESH[(int) (form.a.getX()/SIZE) + 1][(int) (form.a.getY()/SIZE)];
            int moveB = MESH[(int) (form.b.getX()/SIZE) + 1][(int) (form.b.getY()/SIZE)];
            int moveC = MESH[(int) (form.c.getX()/SIZE) + 1][(int) (form.c.getY()/SIZE)];
            int moveD = MESH[(int) (form.d.getX()/SIZE) + 1][(int) (form.d.getY()/SIZE)];
            if(moveA == 0 && moveB == moveA && moveC == moveB && moveD == moveC){
                form.a.setX(form.a.getX() + MOVE);
                form.b.setX(form.b.getX() + MOVE);
                form.c.setX(form.c.getX() + MOVE);
                form.d.setX(form.d.getX() + MOVE);
            }
        }
    }
    public static void moveLeft(Form form){
        if(form.a.getX() - MOVE >= 0 && form.b.getX() - MOVE >= 0 &&
                form.c.getX() - MOVE >= 0 && form.d.getX() - MOVE >= 0){
            int moveA = MESH[(int) (form.a.getX()/SIZE) - 1][(int) (form.a.getY()/SIZE)];
            int moveB = MESH[(int) (form.b.getX()/SIZE) - 1][(int) (form.b.getY()/SIZE)];
            int moveC = MESH[(int) (form.c.getX()/SIZE) - 1][(int) (form.c.getY()/SIZE)];
            int moveD = MESH[(int) (form.d.getX()/SIZE) - 1][(int) (form.d.getY()/SIZE)];
            if(moveA == 0 && moveB == moveA && moveC == moveB && moveD == moveC){
                form.a.setX(form.a.getX() - MOVE);
                form.b.setX(form.b.getX() - MOVE);
                form.c.setX(form.c.getX() - MOVE);
                form.d.setX(form.d.getX() - MOVE);
            }
        }
    }

    public static Form makeRect(){
        int block = (int) (Math.random()*105);
        String name;
        Rectangle a = new Rectangle(SIZE, SIZE),
                b = new Rectangle(SIZE, SIZE),
                c = new Rectangle(SIZE, SIZE),
                d = new Rectangle(SIZE, SIZE);
        Form obj;
        if(block <= 15){
            a.setX(XMAX/2);
            b.setX(XMAX/2);
            b.setY(SIZE);
            c.setX(XMAX/2);
            c.setY(SIZE*2);
            d.setX(XMAX/2+SIZE);
            d.setY(SIZE*2);
            name = "l";
        }
        else if(block<=30 && block>15){
            //.A//...//CD//ABC
            //.B//D..//B.//..D
            //DC//CBA//A.//...
            a.setX(XMAX/2);
            b.setX(XMAX/2);
            b.setY(SIZE);
            c.setX(XMAX/2);
            c.setY(SIZE*2);
            d.setX(XMAX/2-SIZE);
            d.setY(SIZE*2);
            name = "j";
        }
        else if(block<=45 && block > 30){
            a.setX(XMAX/2);
            b.setX(XMAX/2+SIZE);
            c.setX(XMAX/2);
            c.setY(SIZE);
            d.setX(XMAX/2+SIZE);
            d.setY(SIZE);
            name = "o";
        }
        else if(block<=60 && block > 45){
            a.setX(XMAX/2);
            b.setX(XMAX/2+SIZE);
            c.setX(XMAX/2-SIZE);
            c.setY(SIZE);
            d.setX(XMAX/2);
            d.setY(SIZE);
            name = "s";
        }
        else if(block<=75 && block > 60){
            a.setX(XMAX/2);
            b.setX(XMAX/2-SIZE);
            b.setY(SIZE);
            c.setX(XMAX/2);
            c.setY(SIZE);
            d.setX(XMAX/2+SIZE);
            d.setY(SIZE);
            name = "t";
        }
        else if(block<=90 && block > 75){
            a.setX(XMAX/2-SIZE);
            b.setX(XMAX/2);
            c.setX(XMAX/2);
            c.setY(SIZE);
            d.setX(XMAX/2+SIZE);
            d.setY(SIZE);
            name = "z";
        }
        else{
            a.setX(XMAX/2-SIZE);
            b.setX(XMAX/2);
            c.setX(XMAX/2+SIZE);
            d.setX(XMAX/2+SIZE*2);
            name = "i";
        }

        return new Form(a,b,c,d,name);
    }
}