package com.example.tetrisgame;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.*;

public class Tetris extends Application {
    public static final int MOVE = 25;
    public static final int SIZE = 25;
    public static int XMAX = SIZE * 12;
    public static int YMAX = SIZE * 24;
    public static int [][] MESH = new int[XMAX/SIZE][YMAX/SIZE];
    private static Pane groupe = new Pane();
    private static Form object;
    private static Scene scene = new Scene(groupe, XMAX+150, YMAX);
    public static int score = 0;
    public static int top = 0;
    public static boolean game = true;
    public static Form nextObject = Controller.makeRect();
    private static int lineCount = 0;



    @Override
    public void start(Stage stage) throws IOException {
        for (int[] a : MESH) {
            Arrays.fill(a, 0);
        }

        Line line = new Line(XMAX, 0, XMAX, YMAX);
        Text scoreboard = new Text("Score: ");
        scoreboard.setStyle("-fx-font: 20 arial");
        scoreboard.setX(XMAX + 5);
        scoreboard.setY(50);
        Text lines = new Text("Lines: ");
        scoreboard.setStyle("-fx-font: 20 arial");
        scoreboard.setX(XMAX + 5);
        scoreboard.setY(70);
        groupe.getChildren().addAll(line, scoreboard, lines);

        Form newForm = nextObject;
        groupe.getChildren().addAll(newForm.a, newForm.b, newForm.c, newForm.d);
        moveOnKeyPress(newForm);
        object = newForm;
        nextObject = Controller.makeRect();

        stage.setTitle("T E T R I S");
        stage.setScene(scene);
        stage.show();

        Timer fall = new Timer();
        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                Platform.runLater(new Runnable() {
                    @Override
                    public void run() {
                        if (object.a.getY() == 0 || object.b.getY() == 0
                                || object.c.getY() == 0 || object.d.getY() == 0) {
                            top++;
                        } else {
                            top = 0;
                        }
                        if (top == 2) {
                            Text gameOver = new Text("GAME OVER!");
                            gameOver.setStyle("-fx-font: 70 arial;");
                            gameOver.setFill(Color.RED);
                            gameOver.setX(5);
                            gameOver.setY(SIZE * 12);
                            groupe.getChildren().add(gameOver);
                            game = false;
                        }
                        if (top == 15) {
                            //System.exit(0);
                        }
                        if (game) {
                            moveDown(object);
                            scoreboard.setText("Score: " + score);
                            lines.setText("Lines: " + lineCount);
                        }
                    }
                });
            }
        };
        fall.schedule(task, 0, 300);

    }

    private void moveOnKeyPress(Form form){
        scene.setOnKeyPressed(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent keyEvent) {
                switch(keyEvent.getCode()){
                    case RIGHT -> {
                        //Controller.moveRight(form);
                        Controller.moveRight(object);
                    }
                    case LEFT -> {
                        //Controller.moveLeft(form);
                        Controller.moveLeft(object);
                    }
                    case DOWN -> {
                        //moveDown(form);
                        moveDown(object);
                        score++;
                    }
                    case UP -> {
                        //turnForm(form);
                        turnForm(object);
                    }
                }
            }
        });
    }


    private void turnForm(Form form){
        int f = form.form;
        Rectangle a = form.a;
        Rectangle b = form.b;
        Rectangle c = form.c;
        Rectangle d = form.d;
        switch(form.getName()){
            case "j" -> {
                //..A//...//CD.//ABC
                //..B//D..//B..//..D
                //.DC//CBA//A..//...
                switch(f){
                    case 1 -> {
                        moveUp(d);
                        moveLeft(d);
                        moveLeft(c);
                        moveLeft(c);
                        moveDown(b);
                        moveLeft(b);
                        moveDown(a);
                        moveDown(a);
                        form.changeForm();
                    }
                    case 2 -> {
                        moveUp(d);
                        moveRight(d);
                        moveUp(c);
                        moveUp(c);
                        moveLeft(b);
                        moveUp(b);
                        moveLeft(a);
                        moveLeft(a);
                        form.changeForm();
                    }
                    case 3 -> {
                        moveRight(d);
                        moveDown(d);
                        moveRight(c);
                        moveRight(c);
                        moveUp(b);
                        moveRight(b);
                        moveUp(a);
                        moveUp(a);
                        form.changeForm();
                    }
                    case 4 -> {
                        moveDown(d);
                        moveLeft(d);
                        moveDown(c);
                        moveDown(c);
                        moveRight(b);
                        moveDown(b);
                        moveRight(a);
                        moveRight(a);
                        form.changeForm();
                    }
                }
            }
            case "l" -> {
                //A..//CBA//.DC//
                //B..//D..//..B//..D
                //CD.//...//..A//ABC
                switch(f){
                    case 1 -> {
                        moveUp(d);
                        moveLeft(d);
                        moveUp(c);
                        moveUp(c);
                        moveUp(b);
                        moveRight(b);
                        moveRight(a);
                        moveRight(a);
                        form.changeForm();
                    }
                    case 2 -> {
                        moveUp(d);
                        moveRight(d);
                        moveRight(c);
                        moveRight(c);
                        moveRight(b);
                        moveDown(b);
                        moveDown(a);
                        moveDown(a);
                        form.changeForm();
                    }
                    case 3 -> {
                        moveRight(d);
                        moveDown(d);
                        moveDown(c);
                        moveDown(c);
                        moveDown(b);
                        moveLeft(b);
                        moveLeft(a);
                        moveLeft(a);
                        form.changeForm();
                    }
                    case 4 -> {
                        moveDown(d);
                        moveLeft(d);
                        moveLeft(c);
                        moveLeft(c);
                        moveLeft(b);
                        moveUp(b);
                        moveUp(a);
                        moveUp(a);
                        form.changeForm();
                    }
                }
            }
            case "s" -> {
                //.AB//.C.//...//B..
                //CD.//.DA//.DC//AD.
                //...//..B//BA.//.C.
                switch(f){
                    case 1 -> {
                        moveUp(c);
                        moveRight(c);
                        moveDown(b);
                        moveDown(b);
                        moveRight(a);
                        moveDown(a);
                        form.changeForm();
                    }
                    case 2 -> {
                        moveRight(c);
                        moveDown(c);
                        moveLeft(b);
                        moveLeft(b);
                        moveLeft(a);
                        moveDown(a);
                        form.changeForm();
                    }
                    case 3 -> {
                        moveDown(c);
                        moveLeft(c);
                        moveUp(b);
                        moveUp(b);
                        moveLeft(a);
                        moveUp(a);
                        form.changeForm();
                    }
                    case 4 -> {
                        moveLeft(c);
                        moveUp(c);
                        moveRight(b);
                        moveRight(b);
                        moveUp(a);
                        moveRight(a);
                        form.changeForm();
                    }
                }
            }
            case "t" -> {
                //.A.//.B.//...//.D.
                //BCD//.CA//DCB//AC.
                //...//.D.//.A.//.B.
                switch(f){
                    case 1 -> {
                        moveDown(d);
                        moveLeft(d);
                        moveUp(b);
                        moveRight(b);
                        moveRight(a);
                        moveDown(a);
                        form.changeForm();
                    }
                    case 2 -> {
                        moveLeft(d);
                        moveUp(d);
                        moveRight(b);
                        moveDown(b);
                        moveDown(a);
                        moveLeft(a);
                        form.changeForm();
                    }
                    case 3 -> {
                        moveUp(d);
                        moveRight(d);
                        moveDown(b);
                        moveLeft(b);
                        moveLeft(a);
                        moveUp(a);
                        form.changeForm();
                    }
                    case 4 -> {
                        moveRight(d);
                        moveDown(d);
                        moveLeft(b);
                        moveUp(b);
                        moveUp(a);
                        moveRight(a);
                        form.changeForm();
                    }
                }
            }
            case "z" -> {
                //AB.//..A//...//.D.
                //.CD//.CB//DC.//BC.
                //...//.D.//.BA//A..
                switch(f){
                    case 1 -> {
                        moveDown(d);
                        moveLeft(d);
                        moveDown(b);
                        moveRight(b);
                        moveRight(a);
                        moveRight(a);
                        form.changeForm();
                    }
                    case 2 -> {
                        moveLeft(d);
                        moveUp(d);
                        moveLeft(b);
                        moveDown(b);
                        moveDown(a);
                        moveDown(a);
                        form.changeForm();
                    }
                    case 3 -> {
                        moveUp(d);
                        moveRight(d);
                        moveUp(b);
                        moveLeft(b);
                        moveLeft(a);
                        moveLeft(a);
                        form.changeForm();
                    }
                    case 4 -> {
                        moveRight(d);
                        moveDown(d);
                        moveRight(b);
                        moveUp(b);
                        moveUp(a);
                        moveUp(a);
                        form.changeForm();
                    }
                }
            }
            case "i" -> {
                //ABCD//..A.//DCBA//..D.
                //....//..B.//....//..C.
                //....//..C.//....//..B.
                //....//..D.//....//..A.
                switch(f){
                    case 1 -> {
                        moveLeft(d);
                        moveDown(d);
                        moveDown(d);
                        moveDown(d);
                        moveDown(c);
                        moveDown(c);
                        moveDown(b);
                        moveRight(b);
                        moveRight(a);
                        moveRight(a);
                        form.changeForm();
                    }
                    case 2 -> {
                        moveUp(d);
                        moveUp(d);
                        moveUp(d);
                        moveLeft(d);
                        moveLeft(d);
                        moveLeft(c);
                        moveUp(c);
                        moveUp(c);
                        moveUp(b);
                        moveRight(a);
                        form.changeForm();
                    }
                    case 3 -> {
                        moveLeft(a);
                        moveDown(a);
                        moveDown(a);
                        moveDown(a);
                        moveDown(b);
                        moveDown(b);
                        moveDown(c);
                        moveRight(c);
                        moveRight(d);
                        moveRight(d);
                        form.changeForm();
                    }
                    case 4 -> {
                        moveUp(a);
                        moveUp(a);
                        moveUp(a);
                        moveLeft(a);
                        moveLeft(a);
                        moveLeft(b);
                        moveUp(b);
                        moveUp(b);
                        moveUp(c);
                        moveRight(d);
                        form.changeForm();
                    }
                }
            }
        }
    }


    private void moveLeft(Rectangle rect){
        if(rect.getX()-MOVE >= 0){
            rect.setX(rect.getX()-MOVE);
        }
    }
    private void moveUp(Rectangle rect){
        if(rect.getY() - MOVE >= 0){
            rect.setY(rect.getY()-MOVE);
        }
    }
    private void moveDown(Rectangle rect){
        if(rect.getY() + MOVE < YMAX){
            rect.setY(rect.getY()+MOVE);
        }
    }
    private void moveRight(Rectangle rect){
        if(rect.getX() + MOVE < XMAX - SIZE){
            rect.setX(rect.getX()+MOVE);
        }
    }
    private void moveDown(Form form){
        if(form.a.getY() < YMAX-MOVE && form.b.getY() < YMAX-MOVE
                && form.c.getY() < YMAX-MOVE && form.d.getY() < YMAX-MOVE
                && MESH[(int) (form.a.getX()/SIZE)][(int) (form.a.getY()/SIZE+1)] == 0
                && MESH[(int) (form.b.getX()/SIZE)][(int) (form.b.getY()/SIZE+1)] == 0
                && MESH[(int) (form.c.getX()/SIZE)][(int) (form.c.getY()/SIZE+1)] == 0
                && MESH[(int) (form.d.getX()/SIZE)][(int) (form.d.getY()/SIZE+1)] == 0){
            moveDown(form.a);
            moveDown(form.b);
            moveDown(form.c);
            moveDown(form.d);
        }
        else{
            sealForm(form);
        }

    }
    private boolean cB(Rectangle rect, int x, int y){
        boolean xb = false;
        boolean yb = false;
        if(x>=0){
            xb = rect.getX() + x*MOVE <= XMAX - SIZE;
        }
        if(x<0){
            xb = rect.getX() + x*MOVE >= 0;
        }
        if(y>=0){
            yb = rect.getY() + y*MOVE > 0;
        }
        if(y<0){
            yb = rect.getY() + y*MOVE < YMAX;
        }
        return xb && yb && MESH[(int) (rect.getX()/SIZE+x)][(int) (rect.getY()/SIZE-y)] == 0;
    }


    private void sealForm(Form form){
        MESH[(int) (form.a.getX()/SIZE)][(int) (form.a.getY()/SIZE)] = 1;
        MESH[(int) (form.b.getX()/SIZE)][(int) (form.b.getY()/SIZE)] = 1;
        MESH[(int) (form.c.getX()/SIZE)][(int) (form.c.getY()/SIZE)] = 1;
        MESH[(int) (form.d.getX()/SIZE)][(int) (form.d.getY()/SIZE)] = 1;
        //groupe.getChildren().addAll(form.a, form.b, form.c, form.d);
        object = nextObject;
        nextObject = Controller.makeRect();
        groupe.getChildren().addAll(object.a, object.b, object.c, object.d);
        removeRows(groupe);
    }

    private void removeRows(Pane pane){
        List<Node> rects = new ArrayList<>();
        List<Integer> lines = new ArrayList<>();
        List<Node> newRects = new ArrayList<>();
        int full = 0;
        for(int i = 0; i<MESH[0].length; i++){
            for(int j = 0; j<MESH.length; j++){
                if(MESH[j][i] == 1){
                    full++;
                }
            }
            if(full == MESH.length){
                lines.add(i+lines.size());
                //lines.add(j);
            }
            full = 0;
        }
        if(lines.size()>0){
            do{
                for(Node node : pane.getChildren()){
                    if(node instanceof Rectangle){
                        rects.add(node);
                    }
                }
                score += 50;
                lineCount++;
                for(Node node : rects){
                    Rectangle a = (Rectangle) node;
                    if(a.getY() == lines.get(0)*SIZE){
                        MESH[(int) (a.getX()/SIZE)][(int)(a.getY()/SIZE)] = 0;
                        pane.getChildren().remove(node);
                    }
                    else{
                        newRects.add(node);
                    }
                }
                for(Node node : newRects){
                    Rectangle a = (Rectangle) node;
                    if(a.getY() < lines.get(0)*SIZE && a.getY() > 2*SIZE){
                        MESH[(int)(a.getX()/SIZE)][(int)(a.getY()/SIZE)] = 0;
                        a.setY(a.getY()+SIZE);
                        MESH[(int)(a.getX()/SIZE)][(int)(a.getY()/SIZE)] = 1;
                    }
                }
                pane.getChildren().removeAll(rects);
                pane.getChildren().addAll(newRects);
                //lines.remove(0);
                rects.clear();
                newRects.clear();
                for(int i = 0; i< lines.size(); i++){
                    if(lines.get(i)<lines.get(0)){
                        lines.set(i, lines.get(i)+1);
                    }
                }
                lines.remove(0);
//                for(Node node: pane.getChildren()){
//                    if(node instanceof Rectangle){
//                        rects.add(node);
//                    }
//                }
//                for(Node node: rects){
//                    Rectangle a = (Rectangle) node;
//                    try{
//                        MESH[(int) (a.getX()/SIZE)][(int) (a.getY()/SIZE)] = 1;
//                    }
//                    catch (ArrayIndexOutOfBoundsException e){
//
//                    }
//                }
//                rects.clear();
            }while(lines.size()>0);

        }
    }
    private void removeRows2(Pane pane){
        List<Node> rects = new ArrayList<>();
        List<Integer> rows = new ArrayList<>();
        List<Node> newRects = new ArrayList<>();
        int full = 0;
        for(int i = 0; i<MESH[0].length; i++){
            for(int j = 0; j<MESH.length; j++){
                if(MESH[j][i] == 1){
                    full++;
                }
            }
            if(full == MESH.length){
                rows.add(i+rows.size());
            }
            full = 0;
        }
        while(rows.size()>0){
            for(Node node : pane.getChildren()){
                if(node instanceof Rectangle){
                    rects.add(node);
                }
            }
            for(Node node : rects){
                Rectangle a = (Rectangle) node;
                if(a.getY() == rows.get(0)*SIZE){
                    pane.getChildren().remove(node);
                    MESH[(int)(a.getX()/SIZE)][(int)(a.getY()/SIZE)]=0;
                }
                else{
                    newRects.add(node);
                }
            }
            for(Node node : newRects){
                Rectangle a = (Rectangle) node;
                if(a.getY() < rows.get(0)*SIZE){
                    MESH[(int)(a.getX()/SIZE)][(int)(a.getY()/SIZE)]=0;
                    double y = a.getY();
                    a.setY(y+SIZE);
                    MESH[(int)(a.getX()/SIZE)][(int)(a.getY()/SIZE)]=1;
                }
            }
            pane.getChildren().removeAll(rects);
            pane.getChildren().addAll(newRects);
            rects.clear();
            newRects.clear();

        }
    }

    public static void main(String[] args) {
        launch();
    }
}